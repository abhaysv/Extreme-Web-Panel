<?php 

class Smtp__none extends lxDriverClass
{
	static function installMe()
	{
		// no action because 'none' driver
	}

	static function uninstallMe()
	{
		// no action because 'none' driver
	}
}
