<?php 

class Mailincoming__none extends lxDriverClass
{
	static function installMe()
	{
		// no action because 'none' driver
	}

	static function uninstallMe()
	{
		// no action because 'none' driver
	}
}
