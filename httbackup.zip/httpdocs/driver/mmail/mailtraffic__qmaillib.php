<?php 

class mailtraffic__qmail extends lxDriverClass {


}
