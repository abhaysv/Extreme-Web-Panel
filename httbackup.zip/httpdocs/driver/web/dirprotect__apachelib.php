<?php 

include_once("dirprotect__lib.php");

class dirprotect__apache extends dirprotect__
{

}
