<?php 

include_once("dirprotect__lib.php");

class dirprotect__hiawathaproxy extends dirprotect__
{

}
