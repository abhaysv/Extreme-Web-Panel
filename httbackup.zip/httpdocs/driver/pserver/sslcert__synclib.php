<?php 

class sslCert__sync extends lxDriverClass
{

}

