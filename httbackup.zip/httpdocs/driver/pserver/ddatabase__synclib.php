<?php 

class ddatabase__Sync extends lxDriverClass {

function write () {}
function get() {}
}

