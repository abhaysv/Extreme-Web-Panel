<?php 
chdir("..");
include_once "lib/html/include.php";

webcommandline_main();
