<?php 

class Domaintraffic extends Lxdb
{
	// Core

	// Data
	static $__desc = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_nname = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_domain_name = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_oldtimestamp = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_timestamp = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_maildisk_usage = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_traffic_usage = Array("", "Device Name",  "name_of_the_device_");
	static $__desc_disk_usage = Array("", "Device Name",  "name_of_the_device_");

	// Objects

	// Lists

	function isSync()
	{
		return false;
	}
}






