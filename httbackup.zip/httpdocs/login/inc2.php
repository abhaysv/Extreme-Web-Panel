<?php
	include_once "../lib/redirect.php";

	$page = 'Login';
?>

	<link href="/theme/css/common.css" rel="stylesheet" type="text/css" />
	<link href="/theme/css/admin_login.css" rel="stylesheet" type="text/css" />

	<script language="javascript" src="/theme/js/login.js"></script>
	<script language="javascript" src="/theme/js/preop.js"></script>
	<script language="javascript" src="/theme/js/lxa.js"></script>
